﻿namespace _20_02_cs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}